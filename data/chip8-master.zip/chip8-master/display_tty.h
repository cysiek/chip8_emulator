#ifndef DISPLAY_TTY_H_
#define DISPLAY_TTY_H_

#include <stdio.h>
#include <stdlib.h>

#include "memory.h"

void draw_tty(chip8_mem*);

#endif // DISPLAY_TTY_H_
